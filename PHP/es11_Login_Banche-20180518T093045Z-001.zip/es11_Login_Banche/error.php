<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Es05</title>
    <style>
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <script type="text/javascript" src="../jquery/jquery-3.2.1.js"></script>

    <!--<script type="application/javascript" src="index.js"></script>-->
</head>
<body>
<?php
$smg=$_GET["error"];
$titolo=$_GET["titolo"];
echo $titolo."<br>".$smg . "<br>";
echo "<a href='index.php'> Torna alla pagina principale</a>"
/**
 * Created by PhpStorm.
 * User: n.gazzera.9926
 * Date: 15/03/2018
 * Time: 12:57
 */ ?>
</body>
</html>
